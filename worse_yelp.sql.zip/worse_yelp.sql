--
-- Database: `worse_yelp`
--
CREATE DATABASE IF NOT EXISTS `worse_yelp` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `worse_yelp`;

-- --------------------------------------------------------

--
-- Table structure for table `cuisines`
--

CREATE TABLE `cuisines` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cuisines`
--

INSERT INTO `cuisines` (`name`, `id`) VALUES
('''Murican', 1),
('Ethiopian', 2),
('Italian', 3),
('Japanese', 4),
('Thai', 5),
('Desserts', 6);

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `cuisine_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `cost` int(255) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`name`, `id`, `cuisine_id`, `description`, `cost`, `rating`) VALUES
('Macaroon Grill', 1, 1, NULL, 5, 1),
('Tasty n Sons', 2, 1, NULL, 4, 2),
('Iconic', 3, 1, NULL, 3, 3),
('EastBurn', 4, 1, NULL, 4, 2),
('Screen Door', 5, 1, NULL, 2, 4),
('Desta', 6, 2, NULL, 5, 1),
('Queen of Sheba', 7, 2, NULL, 4, 2),
('Emame', 8, 2, NULL, 3, 3),
('Meatballs Galore', 9, 3, NULL, 5, 1),
('Nostrana', 10, 3, NULL, 4, 2),
('Lucca', 11, 3, NULL, 3, 3),
('Acconto', 12, 3, NULL, 2, 4),
('Mario Cart', 13, 3, NULL, 1, 5),
('Fujiyama', 14, 4, NULL, 5, 1),
('Bamboo', 15, 4, NULL, 5, 2),
('Masu', 16, 4, NULL, 4, 3),
('Tokio Table', 17, 4, NULL, 3, 2),
('Pok Pok', 18, 5, NULL, 3, 2),
('Esan', 19, 5, NULL, 3, 4),
('Mai Thai', 20, 5, NULL, 2, 3),
('Appethaizing', 21, 5, NULL, 1, 1),
('Petunias', 22, 6, NULL, 3, 4),
('Salt n Straw', 23, 6, NULL, 5, 2),
('Papa Haydn', 24, 6, NULL, 1, 5),
('Blue Star', 25, 6, NULL, 5, 3),
('Random Order', 26, 6, NULL, 2, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuisines`
--
ALTER TABLE `cuisines`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuisines`
--
ALTER TABLE `cuisines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
